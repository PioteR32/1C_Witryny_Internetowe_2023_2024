function insertData()
{
    let text = document.getElementById("inputId").value;
    document.getElementById("divId").innerText = text;
}