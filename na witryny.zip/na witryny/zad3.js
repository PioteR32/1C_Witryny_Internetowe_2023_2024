function insertData()
{
    document.getElementById("inputId").value = "Hello World";
}