function insertData()
{
    let div = document.getElementById("divZad10");
    let width = div.offsetWidth;
    div.style.width = width + 50 + "px";
}