function insertData()
{
    let newLi = document.createElement("li");
    newLi.textContent =  document.getElementById("inputId").value;
    document.getElementById("ulId").appendChild(newLi);
}