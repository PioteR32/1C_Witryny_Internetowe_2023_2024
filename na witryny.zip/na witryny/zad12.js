document.getElementById("p12").addEventListener("click",function(event)
{
    switch (event.button) {
        case 0:
            
            break;
        case 1:

            break;
        case 2:
            alert("Kliknięto prawym przyciskiem ");
            break;
        default:
    }
})