function insertData()
{
    let text = document.getElementById("pId").innerText;
    document.getElementById("inputId").value = text;
}