function insertData()
{
    let div = document.getElementById("buttonId").innerText = "Podwójne kliknięcie";
}