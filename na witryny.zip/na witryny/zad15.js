
document.getElementById("divZad7").addEventListener("mouseover",function ()
{
    document.getElementById("divZad7").addEventListener("mousemove",function (event){
        document.getElementById("divZad7").innerText =  "X: " + event.clientX + " Y: " + event.clientY;
    });    
});
document.getElementById("divZad7").addEventListener("mouseout", ()=> {
    document.getElementById("divZad7").removeEventListener("mousemove",()=>{});
    document.getElementById("divZad7").innerText = "";
}
);