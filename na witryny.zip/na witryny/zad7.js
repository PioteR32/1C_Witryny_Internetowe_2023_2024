
document.getElementById("divZad7").addEventListener("mouseover",()=>{
    document.getElementById("divZad7").style.backgroundColor = "red";
});
document.getElementById("divZad7").addEventListener("mouseout",()=>{
    document.getElementById("divZad7").style.backgroundColor = "green";
});