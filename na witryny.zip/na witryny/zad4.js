function insertData()
{
    document.getElementById("inputId").value 
    =  document.getElementById("inputId").placeholder;
}