
document.addEventListener("keypress",function(event)
{
    if(event.keyCode == 13)
        document.getElementById("buttonId").style.backgroundColor = getRandomColor();
}
)
