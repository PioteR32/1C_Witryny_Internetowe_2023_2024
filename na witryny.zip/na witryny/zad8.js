document.getElementById("p8").addEventListener("click",()=>{
    document.getElementById("p8").style.fontWeight = "bold";
    document.getElementById("p8").style.color = "blue";
});
